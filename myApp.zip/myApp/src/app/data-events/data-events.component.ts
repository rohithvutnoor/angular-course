import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-data-events",
  templateUrl: "./data-events.component.html",
  styleUrls: ["./data-events.component.css"]
})
export class DataEventsComponent implements OnInit {
  sampleText = "Hi I am bound here using string interpolation method";

  imageUrl =
    "https://10clouds.com/wp-content/uploads/2018/03/so-simple-right.png";

  isActive = true;

  sample = "";

  currencyValue = 5897;

  constructor() {}

  ngOnInit() {}

  logSomething() {
    console.log(
      "Logging something here since you called this method on the click event"
    );
  }

  logName(value) {
    console.log(`Your event data is -> ${value}`);
  }
}
