import { Component } from "@angular/core";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent {
  title = "myApp";

  name = "";

  onChangeName(event) {
    // this.name = this.name
    //   .split("")
    //   .reverse()
    //   .join("");

    this.name = event;
  }
}
