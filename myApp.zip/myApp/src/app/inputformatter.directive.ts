import { Directive, HostListener, Input, ElementRef } from "@angular/core";
import { format } from "util";

@Directive({
  selector: "[appInputformatter]"
})
export class InputformatterDirective {
  @Input("format") format;

  constructor(private el: ElementRef) {}

  @HostListener("blur") onblur() {
    let value = this.el.nativeElement.value;
    if (this.format === "uppercase") {
      this.el.nativeElement.value = value.toUpperCase();
    } else {
      this.el.nativeElement.value = value.toLowerCase();
    }
  }
}
