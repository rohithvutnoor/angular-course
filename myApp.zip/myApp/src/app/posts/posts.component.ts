import { Component, Input, Output, EventEmitter } from "@angular/core";
import { DataService } from "../data.service";

@Component({
  selector: "app-posts",
  templateUrl: "./posts.component.html",
  styleUrls: ["./posts.component.css"]
})
export class PostsComponent {
  @Input("name") myName;
  @Output("change") changed = new EventEmitter();

  changeName() {
    this.myName = this.myName
      .split("")
      .reverse()
      .join("");
    this.changed.emit(this.myName);
  }
}
