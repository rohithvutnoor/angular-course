import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-directives-example",
  templateUrl: "./directives-example.component.html",
  styleUrls: ["./directives-example.component.css"]
})
export class DirectivesExampleComponent implements OnInit {
  showPara = true;
  names = ["max", "alice", "james"];
  case = 3;
  isWarning = false;
  constructor() {}

  ngOnInit() {}
}
