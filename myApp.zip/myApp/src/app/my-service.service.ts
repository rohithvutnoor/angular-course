import { Injectable } from "@angular/core";
import { DataService } from "./data.service";

@Injectable()
export class MyServiceService {
  constructor(private postService: DataService) {}

  xyz() {
    this.postService.reverseName("jgkfj");
  }
}
