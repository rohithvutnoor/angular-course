import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-parent-component",
  templateUrl: "./parent-component.component.html",
  styleUrls: ["./parent-component.component.css"]
})
export class ParentComponentComponent implements OnInit {
  myName = "Max";
  constructor() {}

  ngOnInit() {}

  onNameChange(event) {
    console.log(event);
    this.myName = event;
  }
}
