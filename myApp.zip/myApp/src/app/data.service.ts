export class DataService {
  reverseName(input: string) {
    return input
      .split("")
      .reverse()
      .join("");
  }
}
