import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";

import { AppComponent } from "./app.component";
import { PostsComponent } from "./posts/posts.component";
import { ListsComponent } from "./lists/lists.component";
import { DataService } from "./data.service";
import { FormsModule } from "@angular/forms";
import { SummaryPipe } from "./summary.pipe";
import { InputformatterDirective } from "./inputformatter.directive";
import { HttpDataService } from "./http-data.service";
import { HttpClientModule } from "@angular/common/http";
import { DataEventsComponent } from './data-events/data-events.component';
import { ParentComponentComponent } from './parent-component/parent-component.component';
import { ChildComponentComponent } from './child-component/child-component.component';
import { DirectivesExampleComponent } from './directives-example/directives-example.component';

@NgModule({
  declarations: [
    AppComponent,
    PostsComponent,
    ListsComponent,
    SummaryPipe,
    InputformatterDirective,
    DataEventsComponent,
    ParentComponentComponent,
    ChildComponentComponent,
    DirectivesExampleComponent
  ],
  imports: [BrowserModule, FormsModule, HttpClientModule],
  providers: [DataService, HttpDataService],
  bootstrap: [AppComponent]
})
export class AppModule {}
