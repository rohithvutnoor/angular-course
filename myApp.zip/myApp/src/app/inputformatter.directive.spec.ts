import { InputformatterDirective } from './inputformatter.directive';

describe('InputformatterDirective', () => {
  it('should create an instance', () => {
    const directive = new InputformatterDirective();
    expect(directive).toBeTruthy();
  });
});
