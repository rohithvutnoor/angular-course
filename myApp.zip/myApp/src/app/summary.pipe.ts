import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "summary"
})
export class SummaryPipe implements PipeTransform {
  transform(value: any, length: any) {
    if (!length) {
      return value.substr(0, 10);
    } else {
      return value.substr(0, length);
    }
  }
}
