import { Component, OnInit, ElementRef } from "@angular/core";
import { HttpDataService } from "../http-data.service";

@Component({
  selector: "app-lists",
  templateUrl: "./lists.component.html",
  styleUrls: ["./lists.component.css"]
})
export class ListsComponent implements OnInit {
  employeeName = "";
  employeeDesc = "";

  contactType = "asdas";

  constructor(private httpService: HttpDataService) {}

  ngOnInit() {}

  dataInput = "";

  employees = [
    {
      id: 1,
      name: "Alex",
      description: "Hard working, dedicated"
    },
    {
      id: 2,
      name: "Kane",
      description: "Taken back, chilled"
    }
  ];

  createEmployee() {
    let employee = {
      id: this.employees.length,
      name: this.employeeName,
      description: this.employeeDesc
    };

    this.employees.push(employee);
    this.employeeName = "";
    this.employeeDesc = "";
  }

  deleteEmployee(employee) {
    let index = this.employees.indexOf(employee);
    this.employees.splice(index, 1);
  }

  trackEmployee(index, employee) {
    return employee ? employee.id : undefined;
  }

  getPosts() {
    this.httpService.getPosts().subscribe();
  }
}
